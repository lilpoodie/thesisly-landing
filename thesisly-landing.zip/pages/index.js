
import { useState } from 'react';

export default function Home() {
  const [topic, setTopic] = useState('');
  const [proposal, setProposal] = useState('');
  const [loading, setLoading] = useState(false);

  async function generateProposal() {
    if (!topic.trim()) {
      setProposal('Please enter a topic.');
      return;
    }
    setLoading(true);
    setProposal('Loading...');
    try {
      const res = await fetch('/api/proposal', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ topic }),
      });
      if (!res.ok) throw new Error('Failed to fetch proposal');
      const data = await res.json();
      setProposal(data.proposal);
    } catch (e) {
      setProposal('Error generating proposal: ' + e.message);
    }
    setLoading(false);
  }

  return (
    <main style={{ maxWidth: 600, margin: '2rem auto', fontFamily: 'Arial, sans-serif' }}>
      <h1>Thesisly Proposal Generator</h1>
      <p>Enter a thesis topic below and get a sample proposal instantly.</p>
      <input
        type="text"
        placeholder="Enter your thesis topic"
        value={topic}
        onChange={(e) => setTopic(e.target.value)}
        style={{ width: '100%', padding: '0.5rem', fontSize: '1rem' }}
        disabled={loading}
      />
      <button onClick={generateProposal} disabled={loading} style={{ marginTop: '1rem', padding: '0.5rem 1rem', fontSize: '1rem' }}>
        Generate Proposal
      </button>

      <section style={{ marginTop: '2rem' }}>
        <h2>Here's a sample proposal for: <em>{topic || '____'}</em></h2>
        <p style={{ whiteSpace: 'pre-line', minHeight: '150px', backgroundColor: '#f9f9f9', padding: '1rem', borderRadius: '4px' }}>
          {proposal || 'Your proposal will appear here.'}
        </p>
      </section>

      <section style={{ marginTop: '3rem', padding: '1rem', backgroundColor: '#eee', borderRadius: '6px' }}>
        <h2>Support the Mission</h2>
        <p>To finish development, we are requesting a $13,000 startup loan to finalize features, launch a beta program, and begin marketing. Your support can help transform the way academic work gets done.</p>
        <a href="#" style={{ display: 'inline-block', backgroundColor: '#0070f3', color: 'white', padding: '0.5rem 1rem', borderRadius: '4px', textDecoration: 'none' }}>Support Now</a>
      </section>

      <section id="email-signup" style={{ marginTop: '2rem', padding: '2rem', backgroundColor: '#f9f9f9', textAlign: 'center' }}>
        <h2>Join the Waitlist</h2>
        <p>Be the first to try Thesisly when it launches.</p>
        <form action="https://formspree.io/f/xgvykpdj" method="POST" style={{ maxWidth: '400px', margin: 'auto' }}>
          <input name="name" type="text" placeholder="Your name" required style={{ width: '100%', padding: '10px', margin: '5px 0' }} />
          <input name="email" type="email" placeholder="Your email" required style={{ width: '100%', padding: '10px', margin: '5px 0' }} />
          <button type="submit" style={{ padding: '10px 20px', marginTop: '10px' }}>Notify Me</button>
        </form>
      </section>
    </main>
  );
}
