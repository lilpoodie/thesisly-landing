
export default async function handler(req, res) {
  if (req.method !== 'POST') {
    return res.status(405).json({ error: 'Method not allowed' });
  }
  const { topic } = req.body;
  if (!topic) {
    return res.status(400).json({ error: 'No topic provided' });
  }

  // Simple dummy AI-generated proposal text
  const proposal = `Title: Investigating ${topic}\n\n` +
    `Abstract:\nThis thesis proposal aims to explore the topic of "${topic}" in depth. ` +
    `The study will address key questions, methodology, and expected outcomes. ` +
    `Through comprehensive research, this project will contribute to the academic field.`

  res.status(200).json({ proposal });
}
